/**
 * Created by AstafyevaLA on 11.06.2014.
 */

// saving settings of popup win
function PopupSettings(lastState, lastTab) {
    this.lastState = lastState;
    this.lastTab = lastTab;
}
