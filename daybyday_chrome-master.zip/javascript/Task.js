/**
 * Created by AstafyevaLA on 29.04.2014.
 */

function Task(name, listId, date, notes, listName) {
    this.name = name;
    this.listId = listId;
    this.listName = listName;
    this.date = date;
    this.notes = notes;
}
