/**
 * Created by Ratchel on 30.04.2014.
 */

// !!!! сейчас используется мой клиентИД (prevedyolko) и redirect_uri зарегистрированный там. redirect_uri должен содержать id расширения в списке расширений Chrome
c_redirect_uri = 'https://ikdagmjjppfokpdndeanigmajnnmindd.chromiumapp.org/oauth2callback'; //'https://hkhmdpfhbibbgdgjldifjmdlhmgllppn.chromiumapp.org/oauth2callback';

//c_client_id = '783125393148-v9beifuv9alr3e2u1eiamujqrq48948k.apps.googleusercontent.com';
c_client_id = '492637198173-9isjidn1cm3cmt92n5rkmp8kfll8dgk4.apps.googleusercontent.com';
c_client_secret = '';
c_scope = 'https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fcalendar+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Ftasks+https://www.googleapis.com/auth/userinfo.profile';

//c_api_key = 'AIzaSyCp5RxLJciIyr8PHRg2PaXdH37PKm9A7jQ';


